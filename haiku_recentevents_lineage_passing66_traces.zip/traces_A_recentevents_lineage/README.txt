Texera DataflowAgent (Haiku-4.5) — traces for the system with BOTH recent-events AND lineage ON.

System: DataflowSystemHaiku45Annot2LineageThoughtReplay
  context_mode=latest, flow_level=2 (lineage), data_level=2, thoughtReplay=ON (recent-events), char 1000/3000

Filter: kept only PASSING tasks — native KramaBench score > 0.9, scored by the unmodified
evaluate suite with the REAL gpt-4o-mini judge (evaluate_dataflow_system.sh --use_system_cache).
66 of 104 tasks kept: legal 25, environment 13, wildfire 15, archeology 4, astronomy 3, biomedical 6.

Each task dir: prompt.txt, react_steps.json, workflow.json, answer.json, ground_truth.json, stats.json, config.json
Also: system_prompt.md (verbatim CODE-mode system prompt), tools.json (the 2 core tools, OpenAI format)
