Texera DataflowAgent (Haiku-4.5) — traces for the system with BOTH recent-events AND lineage ON.

System: DataflowSystemHaiku45Annot2LineageThoughtReplay
  context_mode=latest, flow_level=2 (lineage), data_level=2, thoughtReplay=ON (recent-events), char 1000/3000

Filter: kept only PASSING tasks — native KramaBench score > 0.9, scored by the unmodified
evaluate suite with the REAL gpt-4o-mini judge (evaluate_dataflow_system.sh --use_system_cache).
66 of 104 tasks kept: legal 25, environment 13, wildfire 15, archeology 4, astronomy 3, biomedical 6.

Each task dir: prompt.txt, react_steps.json, workflow.json, answer.json, ground_truth.json, stats.json, config.json
Also: system_prompt.md (verbatim CODE-mode system prompt), tools.json (the 2 core tools, OpenAI format)

----------------------------------------------------------------------
ADDED: gpt-5-mini solved-task folders (peer comparison)
----------------------------------------------------------------------
Two extra top-level folders hold the tasks that gpt-5-mini SOLVED among the
38 tasks the Haiku both-flags system above FAILED:

  gpt5mini_replayON_solved7/   DataflowSystemGPT5MiniAnnot2LineageThoughtReplay
                               (latest, flow2/lineage, data2, thoughtReplay=ON K=5)
                               7 solved: archeology-hard-7, astronomy-easy-6,
                               environment-easy-3, environment-hard-18,
                               environment-hard-8, legal-hard-18, wildfire-easy-9

  gpt5mini_replayOFF_solved7/  DataflowSystemGPT5MiniAnnot2Lineage
                               (latest, flow2/lineage, data2, thoughtReplay=OFF)
                               7 solved: biomedical-hard-7, environment-easy-3,
                               environment-hard-18, environment-hard-8,
                               legal-hard-18, wildfire-easy-9, wildfire-hard-12

Shared by both (5): environment-easy-3, environment-hard-18, environment-hard-8,
legal-hard-18, wildfire-easy-9.  ON-only: archeology-hard-7, astronomy-easy-6.
OFF-only: biomedical-hard-7, wildfire-hard-12.

Same passing bar and judge (native KramaBench score > 0.9, real gpt-4o-mini).
Each folder also has manifest.json (per-task metric+score) and README.txt.
